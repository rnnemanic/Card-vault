const STORAGE_KEY = "richards_card_vault_v2";
let cards = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
let deferredPrompt = null;

const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat("en-US", {style:"currency", currency:"USD"}).format(Number(n || 0));
const fields = ["cardId","player","year","brand","setName","cardNumber","parallel","serial","grade","cert","purchase","value","status","comp","checked","notes"];

function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(cards)); render(); }
function toast(msg){ const t=document.createElement('div'); t.className='toast'; t.textContent=msg; document.body.appendChild(t); setTimeout(()=>t.remove(),2200); }
function isOneOfOne(c){ return String(c.serial||"").trim().toLowerCase().replaceAll(" ","").includes("1/1"); }
function readFile(input){
  return new Promise(resolve => {
    const file = input.files?.[0];
    if(!file) return resolve(null);
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(file);
  });
}
function clearForm(){ fields.forEach(f => $(f).value = f === "status" ? "PC / Hold" : ""); $("frontPhoto").value=""; $("backPhoto").value=""; }

$("cardForm").addEventListener("submit", async e => {
  e.preventDefault();
  const id = $("cardId").value || crypto.randomUUID();
  const existing = cards.find(c => c.id === id) || {};
  const front = await readFile($("frontPhoto")) || existing.frontPhoto || "";
  const back = await readFile($("backPhoto")) || existing.backPhoto || "";
  const card = {
    id, addedAt: existing.addedAt || new Date().toISOString(), updatedAt: new Date().toISOString(),
    player: $("player").value.trim(), year: $("year").value.trim(), brand: $("brand").value.trim(), setName: $("setName").value.trim(),
    cardNumber: $("cardNumber").value.trim(), parallel: $("parallel").value.trim(), serial: $("serial").value.trim(), grade: $("grade").value.trim(), cert: $("cert").value.trim(),
    purchase: Number($("purchase").value || 0), value: Number($("value").value || 0), status: $("status").value, comp: $("comp").value.trim(), checked: $("checked").value,
    notes: $("notes").value.trim(), frontPhoto: front, backPhoto: back
  };
  const idx = cards.findIndex(c => c.id === id);
  if(idx >= 0) cards[idx] = card; else cards.unshift(card);
  clearForm(); save(); toast("Card saved.");
});
$("clearForm").addEventListener("click", clearForm);
["search","filterStatus","sortBy"].forEach(id => $(id).addEventListener("input", render));

function render(){
  const totalValue = cards.reduce((s,c)=>s+Number(c.value||0),0);
  const totalCost = cards.reduce((s,c)=>s+Number(c.purchase||0),0);
  $("totalCards").textContent = cards.length;
  $("totalValue").textContent = money(totalValue);
  $("totalCost").textContent = money(totalCost);
  $("profitLoss").textContent = money(totalValue-totalCost);
  $("profitLoss").className = totalValue-totalCost >= 0 ? "gain" : "loss";
  $("oneOfOnes").textContent = cards.filter(isOneOfOne).length;

  let list = [...cards];
  const q = $("search").value.toLowerCase().trim();
  const status = $("filterStatus").value;
  if(q) list = list.filter(c => JSON.stringify(c).toLowerCase().includes(q));
  if(status) list = list.filter(c => c.status === status);
  const sort = $("sortBy").value;
  list.sort((a,b)=>{
    if(sort === "valueDesc") return (b.value||0)-(a.value||0);
    if(sort === "valueAsc") return (a.value||0)-(b.value||0);
    if(sort === "player") return (a.player||"").localeCompare(b.player||"");
    if(sort === "yearDesc") return (b.year||0)-(a.year||0);
    return new Date(b.addedAt)-new Date(a.addedAt);
  });

  const wrap = $("cards"); wrap.innerHTML = "";
  $("emptyState").style.display = list.length ? "none" : "block";
  const tpl = $("cardTemplate");
  list.forEach(c => {
    const node = tpl.content.cloneNode(true);
    node.querySelector("h3").textContent = `${c.player || "Unknown Player"}${c.year ? " • " + c.year : ""}`;
    node.querySelector(".badge").textContent = c.status || "PC / Hold";
    node.querySelector(".meta").textContent = [c.brand,c.setName,c.cardNumber,c.parallel,c.serial,c.grade].filter(Boolean).join(" • ");
    const gain = Number(c.value||0) - Number(c.purchase||0);
    node.querySelector(".money").innerHTML = `<span class="pill">Value: ${money(c.value)}</span><span class="pill">Cost: ${money(c.purchase)}</span><span class="pill ${gain>=0?'gain':'loss'}">P/L: ${money(gain)}</span>`;
    node.querySelector(".details").textContent = [c.cert && `Cert: ${c.cert}`, c.comp && `Comp: ${c.comp}`, c.checked && `Checked: ${c.checked}`].filter(Boolean).join(" • ");
    node.querySelector(".notes").textContent = c.notes || "";
    const photos = node.querySelector(".photos");
    photos.innerHTML = "";
    [c.frontPhoto, c.backPhoto].forEach((src,i)=>{
      if(src){ const img=document.createElement("img"); img.src=src; img.alt=i?"Back photo":"Front photo"; photos.appendChild(img); }
      else { const ph=document.createElement("div"); ph.className="photoPlaceholder"; ph.textContent=i?"Back":"Front"; photos.appendChild(ph); }
    });
    node.querySelector(".edit").addEventListener("click",()=>editCard(c.id));
    node.querySelector(".delete").addEventListener("click",()=>{ if(confirm("Delete this card?")){ cards=cards.filter(x=>x.id!==c.id); save(); }});
    wrap.appendChild(node);
  });
}
function editCard(id){
  const c = cards.find(x=>x.id===id); if(!c) return;
  $("cardId").value=c.id; $("player").value=c.player||""; $("year").value=c.year||""; $("brand").value=c.brand||""; $("setName").value=c.setName||""; $("cardNumber").value=c.cardNumber||""; $("parallel").value=c.parallel||""; $("serial").value=c.serial||""; $("grade").value=c.grade||""; $("cert").value=c.cert||""; $("purchase").value=c.purchase||""; $("value").value=c.value||""; $("status").value=c.status||"PC / Hold"; $("comp").value=c.comp||""; $("checked").value=c.checked||""; $("notes").value=c.notes||"";
  window.scrollTo({top:0,behavior:"smooth"});
}
$("exportJson").addEventListener("click",()=>{
  const blob = new Blob([JSON.stringify(cards,null,2)],{type:"application/json"}); download(blob,`richards-card-vault-backup-${new Date().toISOString().slice(0,10)}.json`);
});
$("exportCsv").addEventListener("click",()=>{
  const cols=["player","year","brand","setName","cardNumber","parallel","serial","grade","cert","purchase","value","status","comp","checked","notes"];
  const esc=v=>`"${String(v??"").replaceAll('"','""')}"`;
  const csv=[cols.join(","),...cards.map(c=>cols.map(k=>esc(c[k])).join(","))].join("\n");
  download(new Blob([csv],{type:"text/csv"}),`richards-card-vault-${new Date().toISOString().slice(0,10)}.csv`);
});
function download(blob,name){ const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=name; a.click(); URL.revokeObjectURL(a.href); }
$("importJson").addEventListener("change",e=>{
  const file=e.target.files[0]; if(!file) return;
  const reader=new FileReader(); reader.onload=()=>{ try{ const incoming=JSON.parse(reader.result); if(!Array.isArray(incoming)) throw new Error(); if(confirm("Replace current vault with this backup?")){ cards=incoming; save(); toast("Backup imported."); }}catch{ alert("That backup file could not be read."); }}; reader.readAsText(file);
});
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferredPrompt = e; $("installBtn").classList.remove("hidden"); });
$("installBtn").addEventListener("click", async()=>{ if(deferredPrompt){ deferredPrompt.prompt(); deferredPrompt=null; $("installBtn").classList.add("hidden"); }});
if("serviceWorker" in navigator){ navigator.serviceWorker.register("service-worker.js").catch(()=>{}); }
render();
