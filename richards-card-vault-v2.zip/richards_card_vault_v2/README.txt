Richard’s Card Vault - Version 2

Open index.html in a browser to use the app.

Features:
- Add any sports card, including 1/1s and obscure parallels
- Set your own estimated value
- Track purchase price, total value, total cost, and profit/loss
- Add front and back card photos
- Search, filter, sort, edit, and delete cards
- Export JSON backups and CSV spreadsheets
- Import a JSON backup
- PWA-ready for adding to a phone home screen after hosting online

Important:
This app stores your cards in the browser/device local storage. Export backups regularly.
For iPhone home-screen use, upload the folder to a simple host like GitHub Pages or Netlify, open the link in Safari, then use Share > Add to Home Screen.
